<?php
    return array(
	 'SYSTEM_ADMINISTRATOR' => '系统管理员',
	 'SEND_SUCCESS' => '发送成功',
	 'SEND' => '发送',
	 'SEND_SUCCESSS' => '发送成功！',
	 'SEND_FAILY' => '发送失败',
	 'SEND_FAILYS' => '发送失败！',
	 'ILLEGAL_ACCESS' => '非法访问！',
	 'NOT_CHOOSE_ANY_CONTENT' => '您没有选择任何内容！',
	 'DELETE_SUCCESS' => '删除成功！',
	 'DELETE_FAILY' => '删除失败！',
	 'PARAMETER_ERROR_DELETE_FALILY'=>'参数错误,删除失败！',
	 'PARAMETER_ERROR_CONTCART_ADMINISTRATOR'=>'参数错误,参数错误，请联系管理员！',
	 'COMPLETE' => '完成',
	 'SHORT_MESSAGE' => '短消息',
	 'SHORT_MESSAGE_VIEW' => '查看短消息',
	 'WRITE_LETTER' => '写信',
	 'INBOX' => '收件箱',
	 'OUTBOX' => '发件箱',
	 'CONTENT' => '内容',
	 'CONTENTSS' => '内容:',
	 'THE_SENDER' => '发件人',
	 'THE_SENDERS' => '发件人：',
	 'THE_RECIPIENT' => '收件人',
	 'SEND_TIME' => '发送时间',
	 'SEND_TIMES' => '发送时间：',
	 'READING_TIME' => '阅读时间',
	 'UNREAD' => '未读',
	 'MAIL_SYSTEM' => '系统邮件',
	 'WRITE_LETTER_IN' => '写站内信',
	 'ARE_YOU_DELETE' => '你确定要删除?',
	 'ARE_YOU_DELETE_RECEIVE' => '你确定要删除receive?',
	 'SELECT_THE_RECIPIENT' => '选择收件人',
	 'SELECT_ALL' => '*全部选择',
	 'CONTENTS'   => '*内容',
	 'REPLY'      => '回复',
	 'SET_READ'   => '设置已读',
	 'CONFIRM_TO_SET_MESAAGE_READ' => '确认要标记为已读？',
	 'SUCCESS_TO_SET_MESSAGE_READ' => '设置已读成功',
	 'FALSE_TO_SET_MESSAGE_READ' => '设置已读失败，数据无变化！',
	 'PLEASE_CHOOSE_MESSAGE_TO_SET_READ'=> '请选择你要设置的站内信',
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	
	);