<?php
class TasksModel extends Model{
}