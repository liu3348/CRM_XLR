<?php
return array(
'VERSION'=>'0.5.0',
'RELEASE'=>'20150312',
);