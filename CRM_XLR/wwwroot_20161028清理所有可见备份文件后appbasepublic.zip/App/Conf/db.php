<?php
//return array(
//'DB_TYPE'=>'mysql',
//'DB_HOST'=>'localhost',
//'DB_PORT'=>'3306',
//'DB_NAME'=>'demo_crm',
//'DB_USER'=>'root',
//'DB_PWD'=>'root',
//'DB_PREFIX'=>'xlr_',
//);

return array(
    'DB_TYPE'=>'mysql',
    'DB_HOST'=>'localhost',
    'DB_PORT'=>'3306',
    'DB_NAME'=>'xlr_crm',
    'DB_USER'=>'xlr_crm',
    'DB_PWD'=>'xlr_crm_20150601',
    'DB_PREFIX'=>'xlr_',
);